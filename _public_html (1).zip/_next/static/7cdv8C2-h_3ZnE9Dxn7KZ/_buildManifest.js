self.__BUILD_MANIFEST = {
    __rewrites: {
        beforeFiles: [],
        afterFiles: [],
        fallback: []
    },
    "/": ["static/css/3bd5382a773cf34c.css", "static/chunks/pages/index-0b8248067edd0782.js"],
    "/_error": ["static/chunks/pages/_error-d419484d69bbcf53.js"],
    "/play": ["static/css/28e04f67ebdc077a.css", "static/chunks/pages/play-762e36993ab54585.js"],
    sortedPages: ["/", "/_app", "/_error", "/play"]
},
self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();
