(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[141], {
    67454: function(e, n, t) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/play", function() {
            return t(49015)
        }
        ])
    },
    15644: function(e, n, t) {
        "use strict";
        t.d(n, {
            Ak: function() {
                return i
            },
            Fy: function() {
                return o
            },
            SX: function() {
                return r
            },
            pj: function() {
                return a
            }
        });
        var a = "0x16A131b7e5a62E8fe83f0993aAF2ECCaBF519382"
          , r = "0x5231B9a9E55739641a63989faec3db4d8F56fBBb"
          , i = "0x18B18e5D2375c592997e1eaFf6C77A6bd24F5c44"
          , o = "0x9d33597aD43bE6295Fe7626baDBF72B862F71bB2"
    },
    49015: function(e, n, t) {
        "use strict";
        t.r(n),
        t.d(n, {
            default: function() {
                return B
            }
        });
        var a = t(85893)
          , r = t(22507)
          , i = t(67294)
          , o = t(34051)
          , c = t.n(o)
          , s = t(17295)
          , d = t.n(s)
          , l = (0,
        a.jsx)("div", {
            className: d().slide,
            children: (0,
            a.jsx)("img", {
                src: "./gold-gem.png",
                height: "48",
                width: "48",
                alt: "gold-gem"
            })
        });
        function m(e) {
            return e.pickaxe ? (0,
            a.jsx)("div", {
                className: d().slider,
                children: (0,
                a.jsxs)("div", {
                    className: d().slideTrack,
                    children: [l, l, l, l, l, l, l, l, l, l, l, l, l]
                })
            }) : (0,
            a.jsx)("div", {
                style: {
                    marginLeft: 8
                },
                children: "I need a pickaxe!"
            })
        }
        var _ = t(7160)
          , u = t.n(_);
        function p(e, n, t, a, r, i, o) {
            try {
                var c = e[i](o)
                  , s = c.value
            } catch (d) {
                return void t(d)
            }
            c.done ? n(s) : Promise.resolve(s).then(a, r)
        }
        function x(e) {
            var n = e.miningContract
              , t = e.characterContract
              , o = e.pickaxeContract
              , s = (0,
            r.SF)()
              , d = (0,
            r.el)(t, 0).data
              , l = (0,
            i.useState)()
              , _ = l[0]
              , x = l[1];
            return (0,
            i.useEffect)((function() {
                var e;
                (e = c().mark((function e() {
                    var t, a;
                    return c().wrap((function(e) {
                        for (; ; )
                            switch (e.prev = e.next) {
                            case 0:
                                if (s) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return e.next = 4,
                                n.call("playerPickaxe", s);
                            case 4:
                                if (!(t = e.sent).isData) {
                                    e.next = 10;
                                    break
                                }
                                return e.next = 8,
                                o.get(t.value);
                            case 8:
                                a = e.sent,
                                x(a);
                            case 10:
                            case "end":
                                return e.stop()
                            }
                    }
                    ), e)
                }
                )),
                function() {
                    var n = this
                      , t = arguments;
                    return new Promise((function(a, r) {
                        var i = e.apply(n, t);
                        function o(e) {
                            p(i, a, r, o, c, "next", e)
                        }
                        function c(e) {
                            p(i, a, r, o, c, "throw", e)
                        }
                        o(void 0)
                    }
                    ))
                }
                )()
            }
            ), [s, n, o]),
            (0,
            a.jsxs)("div", {
                style: {
                    display: "flex",
                    flexDirection: "column"
                },
                children: [(0,
                a.jsx)("h2", {
                    className: "".concat(u().noGapTop, " "),
                    children: "Equipped Items"
                }), (0,
                a.jsxs)("div", {
                    style: {
                        display: "flex",
                        alignItems: "center",
                        flexDirection: "row",
                        justifyContent: "center"
                    },
                    children: [(0,
                    a.jsx)("div", {
                        style: {
                            outline: "1px solid grey",
                            borderRadius: 16
                        },
                        children: d && (0,
                        a.jsx)(r.CH, {
                            metadata: null === d || void 0 === d ? void 0 : d.metadata,
                            height: "64"
                        })
                    }), (0,
                    a.jsx)("div", {
                        style: {
                            outline: "1px solid grey",
                            borderRadius: 16,
                            marginLeft: 8
                        },
                        children: _ && (0,
                        a.jsx)(r.CH, {
                            metadata: _.metadata,
                            height: "64"
                        })
                    })]
                }), (0,
                a.jsxs)("div", {
                    style: {
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        marginTop: 24
                    },
                    children: [(0,
                    a.jsx)("img", {
                        src: "./mine.gif",
                        height: 64,
                        width: 64,
                        alt: "character-mining"
                    }), (0,
                    a.jsx)(m, {
                        pickaxe: _
                    })]
                })]
            })
        }
        function f() {
            return (0,
            a.jsx)("div", {
                className: u().container,
                children: "Loading..."
            })
        }
        var h = t(15644);
        function v(e, n, t, a, r, i, o) {
            try {
                var c = e[i](o)
                  , s = c.value
            } catch (d) {
                return void t(d)
            }
            c.done ? n(s) : Promise.resolve(s).then(a, r)
        }
        function g(e) {
            return function() {
                var n = this
                  , t = arguments;
                return new Promise((function(a, r) {
                    var i = e.apply(n, t);
                    function o(e) {
                        v(i, a, r, o, c, "next", e)
                    }
                    function c(e) {
                        v(i, a, r, o, c, "throw", e)
                    }
                    o(void 0)
                }
                ))
            }
        }
        function j(e) {
            var n = e.pickaxeContract
              , t = e.miningContract
              , i = (0,
            r.SF)()
              , o = (0,
            r.YZ)(n, i)
              , s = o.data;
            if (o.isLoading)
                return (0,
                a.jsx)(f, {});
            function d() {
                return (d = g(c().mark((function e(a) {
                    return c().wrap((function(e) {
                        for (; ; )
                            switch (e.prev = e.next) {
                            case 0:
                                if (i) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return e.next = 4,
                                n.isApproved(i, h.SX);
                            case 4:
                                if (e.sent) {
                                    e.next = 8;
                                    break
                                }
                                return e.next = 8,
                                n.setApprovalForAll(h.SX, !0);
                            case 8:
                                return e.next = 10,
                                t.call("stake", a);
                            case 10:
                                window.location.reload();
                            case 11:
                            case "end":
                                return e.stop()
                            }
                    }
                    ), e)
                }
                )))).apply(this, arguments)
            }
            return (0,
            a.jsx)(a.Fragment, {
                children: (0,
                a.jsx)("div", {
                    className: u().nftBoxGrid,
                    children: null === s || void 0 === s ? void 0 : s.map((function(e) {
                        return (0,
                        a.jsxs)("div", {
                            className: u().nftBox,
                            children: [(0,
                            a.jsx)(r.CH, {
                                metadata: e.metadata,
                                className: "".concat(u().nftMedia, " ").concat(u().spacerTop),
                                height: "64"
                            }), (0,
                            a.jsx)("h3", {
                                children: e.metadata.name
                            }), (0,
                            a.jsx)("div", {
                                className: u().smallMargin,
                                children: (0,
                                a.jsx)(r.tn, {
                                    colorMode: "dark",
                                    contractAddress: h.SX,
                                    action: function() {
                                        return function(e) {
                                            return d.apply(this, arguments)
                                        }(e.metadata.id)
                                    },
                                    children: "Equip"
                                })
                            })]
                        }, e.metadata.id.toString())
                    }
                    ))
                })
            })
        }
        var H = t(35553);
        function C(e, n, t, a, r, i, o) {
            try {
                var c = e[i](o)
                  , s = c.value
            } catch (d) {
                return void t(d)
            }
            c.done ? n(s) : Promise.resolve(s).then(a, r)
        }
        function k(e) {
            var n = e.miningContract
              , t = (0,
            r.SF)()
              , o = parseInt(4761904761904.762.toFixed(0))
              , s = (0,
            i.useState)(0)
              , d = s[0]
              , l = s[1]
              , m = (0,
            i.useState)(0)
              , _ = m[0]
              , u = m[1];
            return (0,
            i.useEffect)((function() {
                var e;
                (e = c().mark((function e() {
                    var a;
                    return c().wrap((function(e) {
                        for (; ; )
                            switch (e.prev = e.next) {
                            case 0:
                                if (t) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return e.next = 4,
                                n.call("playerPickaxe", t);
                            case 4:
                                (a = e.sent).isData ? u(a.value.toNumber() + 1) : u(0);
                            case 6:
                            case "end":
                                return e.stop()
                            }
                    }
                    ), e)
                }
                )),
                function() {
                    var n = this
                      , t = arguments;
                    return new Promise((function(a, r) {
                        var i = e.apply(n, t);
                        function o(e) {
                            C(i, a, r, o, c, "next", e)
                        }
                        function c(e) {
                            C(i, a, r, o, c, "throw", e)
                        }
                        o(void 0)
                    }
                    ))
                }
                )()
            }
            ), [t, n]),
            (0,
            i.useEffect)((function() {
                var e = setInterval((function() {
                    l(d + o)
                }
                ), 100);
                return function() {
                    return clearInterval(e)
                }
            }
            ), [d, o]),
            (0,
            a.jsxs)("p", {
                style: {
                    width: 370,
                    overflow: "hidden"
                },
                children: ["Earned this session:", " ", (0,
                a.jsx)("b", {
                    children: H.formatEther((d * _).toFixed(0)) || "Error..."
                })]
            })
        }
        function w(e) {
            var n = e.miningContract
              , t = e.tokenContract
              , i = (0,
            r.SF)()
              , o = (0,
            r.AQ)(t).data
              , c = (0,
            r.mM)(t, i).data
              , s = (0,
            r.do)(n, "calculateRewards", i).data;
            return (0,
            a.jsxs)("div", {
                style: {
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center"
                },
                children: [(0,
                a.jsxs)("p", {
                    children: ["Your ", (0,
                    a.jsx)("b", {
                        children: "Gold Gems"
                    })]
                }), o && (0,
                a.jsx)(r.CH, {
                    metadata: o,
                    height: "48"
                }), (0,
                a.jsxs)("p", {
                    className: u().noGapBottom,
                    children: ["Balance: ", (0,
                    a.jsx)("b", {
                        children: null === c || void 0 === c ? void 0 : c.displayValue
                    })]
                }), (0,
                a.jsxs)("p", {
                    children: ["Unclaimed:", " ", (0,
                    a.jsx)("b", {
                        children: s && H.formatUnits(s)
                    })]
                }), (0,
                a.jsx)(k, {
                    miningContract: n
                }), (0,
                a.jsx)("div", {
                    className: u().smallMargin,
                    children: (0,
                    a.jsx)(r.tn, {
                        contractAddress: h.SX,
                        action: function(e) {
                            return e.call("claim")
                        },
                        children: "Claim"
                    })
                })]
            })
        }
        function y(e) {
            var n = e.item
              , t = e.pickaxeContract
              , i = (0,
            r.Mb)(t, n.metadata.id).data;
            return (0,
            a.jsxs)("div", {
                className: u().nftBox,
                children: [(0,
                a.jsx)(r.CH, {
                    metadata: n.metadata,
                    className: "".concat(u().nftMedia, " ").concat(u().spacerTop),
                    height: "64"
                }), (0,
                a.jsx)("h3", {
                    children: n.metadata.name
                }), (0,
                a.jsxs)("p", {
                    children: ["Price:", " ", (0,
                    a.jsxs)("b", {
                        children: [i && H.formatUnits(null === i || void 0 === i ? void 0 : i.price), " ", "GEM"]
                    })]
                }), (0,
                a.jsx)("div", {
                    className: u().smallMargin,
                    children: (0,
                    a.jsx)(r.tn, {
                        colorMode: "dark",
                        contractAddress: h.Fy,
                        action: function(e) {
                            return e.erc1155.claim(n.metadata.id, 1)
                        },
                        onSuccess: function() {
                            return alert("Purchased!")
                        },
                        onError: function(e) {
                            return alert(e)
                        },
                        children: "Buy"
                    })
                })]
            }, n.metadata.id.toString())
        }
        function b(e) {
            var n = e.pickaxeContract
              , t = (0,
            r.a1)(n).data;
            return (0,
            a.jsx)(a.Fragment, {
                children: (0,
                a.jsx)("div", {
                    className: u().nftBoxGrid,
                    children: null === t || void 0 === t ? void 0 : t.map((function(e) {
                        return (0,
                        a.jsx)(y, {
                            pickaxeContract: n,
                            item: e
                        }, e.metadata.id.toString())
                    }
                    ))
                })
            })
        }
        function B() {
            var e = (0,
            r.SF)()
              , n = (0,
            r.cq)(h.SX).contract
              , t = (0,
            r.cq)(h.pj, "edition-drop").contract
              , i = (0,
            r.cq)(h.Fy, "edition-drop").contract
              , o = (0,
            r.cq)(h.Ak, "token").contract;
            return e ? (0,
            a.jsxs)("div", {
                className: u().container,
                children: [n && t && o && i ? (0,
                a.jsxs)("div", {
                    className: u().mainSection,
                    children: [(0,
                    a.jsx)(x, {
                        miningContract: n,
                        characterContract: t,
                        pickaxeContract: i
                    }), (0,
                    a.jsx)(w, {
                        miningContract: n,
                        tokenContract: o
                    })]
                }) : (0,
                a.jsx)(f, {}), (0,
                a.jsx)("hr", {
                    className: "".concat(u().divider, " ").concat(u().bigSpacerTop)
                }), i && n ? (0,
                a.jsxs)(a.Fragment, {
                    children: [(0,
                    a.jsx)("h2", {
                        className: "".concat(u().noGapTop, " ").concat(u().noGapBottom),
                        children: "Your Owned Pickaxes"
                    }), (0,
                    a.jsx)("div", {
                        style: {
                            width: "100%",
                            minHeight: "10rem",
                            display: "flex",
                            flexDirection: "row",
                            justifyContent: "center",
                            alignItems: "center",
                            marginTop: 8
                        },
                        children: (0,
                        a.jsx)(j, {
                            pickaxeContract: i,
                            miningContract: n
                        })
                    })]
                }) : (0,
                a.jsx)(f, {}), (0,
                a.jsx)("hr", {
                    className: "".concat(u().divider, " ").concat(u().bigSpacerTop)
                }), i && o ? (0,
                a.jsxs)(a.Fragment, {
                    children: [(0,
                    a.jsx)("h2", {
                        className: "".concat(u().noGapTop, " ").concat(u().noGapBottom),
                        children: "Shop"
                    }), (0,
                    a.jsx)("div", {
                        style: {
                            width: "100%",
                            minHeight: "10rem",
                            display: "flex",
                            flexDirection: "row",
                            justifyContent: "center",
                            alignItems: "center",
                            marginTop: 8
                        },
                        children: (0,
                        a.jsx)(b, {
                            pickaxeContract: i
                        })
                    })]
                }) : (0,
                a.jsx)(f, {})]
            }) : (0,
            a.jsx)("div", {
                className: u().container,
                children: (0,
                a.jsx)(r.RZ, {
                    colorMode: "dark"
                })
            })
        }
    },
    17295: function(e) {
        e.exports = {
            slider: "Gameplay_slider__iCTwF",
            slideTrack: "Gameplay_slideTrack__0PgZM",
            scroll: "Gameplay_scroll__cYe_7",
            slide: "Gameplay_slide__Rztf5"
        }
    },
    7160: function(e) {
        e.exports = {
            connect: "Home_connect__lnU7w",
            smallMargin: "Home_smallMargin__m5aTc",
            btn: "Home_btn__UGRT9",
            address: "Home_address__UT_ly",
            container: "Home_container__bCOhY",
            page: "Home_page__0ydta",
            pageContainer: "Home_pageContainer__wDxoE",
            arrowButton: "Home_arrowButton__1aqew",
            owner: "Home_owner__58_U6",
            btnContainer: "Home_btnContainer__TOUPE",
            header: "Home_header__GCVRv",
            left: "Home_left__T7LhQ",
            right: "Home_right__TcB_0",
            secondaryButton: "Home_secondaryButton__QO332",
            mainButton: "Home_mainButton__dUc5h",
            ourCollection: "Home_ourCollection__OxOvN",
            collectionContainer: "Home_collectionContainer__pwAKU",
            h1: "Home_h1__7tdRW",
            explain: "Home_explain__KljHm",
            purple: "Home_purple__zOX0E",
            divider: "Home_divider__c4Nl_",
            smallDivider: "Home_smallDivider__wG_2a",
            textInput: "Home_textInput__cA71M",
            imageInput: "Home_imageInput__SjLEG",
            contractBoxGrid: "Home_contractBoxGrid__epSaY",
            contractBox: "Home_contractBox__bxUXm",
            nftBoxGrid: "Home_nftBoxGrid__qFzCk",
            nftBox: "Home_nftBox__woiq_",
            tokenGrid: "Home_tokenGrid__vsv91",
            tokenItem: "Home_tokenItem__HsZqC",
            tokenLabel: "Home_tokenLabel__X56dZ",
            tokenValue: "Home_tokenValue__PYZU2",
            center: "Home_center__4BFgC",
            spacerTop: "Home_spacerTop__RGZTg",
            bigSpacerTop: "Home_bigSpacerTop__YrAdY",
            spacerBottom: "Home_spacerBottom__JmsFH",
            cardName: "Home_cardName__wxcZw",
            cardDescription: "Home_cardDescription__iWMlk",
            headerLogo: "Home_headerLogo__qHj_d",
            verticalSpacer: "Home_verticalSpacer__W1YaR",
            codeSnippet: "Home_codeSnippet__gwZEn",
            noUnderline: "Home_noUnderline__SEtQc",
            detailPageContainer: "Home_detailPageContainer__7zwXF",
            detailPageHr: "Home_detailPageHr__JnD4B",
            lightPurple: "Home_lightPurple__8ghLL",
            nftMedia: "Home_nftMedia__0EkUL",
            amountToClaim: "Home_amountToClaim__p1NtW",
            noGapBottom: "Home_noGapBottom__KnGYx",
            noGapTop: "Home_noGapTop__n0WrO",
            mainSection: "Home_mainSection__QeXzC"
        }
    }
}, function(e) {
    e.O(0, [774, 888, 179], (function() {
        return n = 67454,
        e(e.s = n);
        var n
    }
    ));
    var n = e.O();
    _N_E = n
}
]);
