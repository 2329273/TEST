(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([[405], {
    48312: function(e, o, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
            return n(38324)
        }
        ])
    },
    15644: function(e, o, n) {
        "use strict";
        n.d(o, {
            Ak: function() {
                return a
            },
            Fy: function() {
                return r
            },
            SX: function() {
                return t
            },
            pj: function() {
                return _
            }
        });
        var _ = "0x16A131b7e5a62E8fe83f0993aAF2ECCaBF519382"
          , t = "0x5231B9a9E55739641a63989faec3db4d8F56fBBb"
          , a = "0x18B18e5D2375c592997e1eaFf6C77A6bd24F5c44"
          , r = "0x9d33597aD43bE6295Fe7626baDBF72B862F71bB2"
    },
    38324: function(e, o, n) {
        "use strict";
        n.r(o),
        n.d(o, {
            default: function() {
                return d
            }
        });
        var _ = n(85893)
          , t = n(7160)
          , a = n.n(t)
          , r = n(22507)
          , i = n(15644);
        n(67294);
        function c() {
            (0,
            r.SF)();
            return (0,
            _.jsxs)("div", {
                className: a().collectionContainer,
                children: [(0,
                _.jsx)("h1", {
                    children: "Edition Drop"
                }), (0,
                _.jsx)("p", {
                    children: "Claim your Character NFT to start playing!"
                }), (0,
                _.jsx)("div", {
                    className: "".concat(a().nftBox, " ").concat(a().spacerBottom),
                    children: (0,
                    _.jsx)("img", {
                        src: "./mine.gif",
                        style: {
                            height: 200
                        }
                    })
                }), (0,
                _.jsx)("div", {
                    className: a().smallMargin,
                    children: (0,
                    _.jsx)(r.tn, {
                        colorMode: "dark",
                        contractAddress: i.pj,
                        action: function(e) {
                            return e.erc1155.claim(0, 1)
                        },
                        children: "Claim"
                    })
                })]
            })
        }
        var m = n(11163)
          , d = function() {
            var e = (0,
            r.cq)(i.pj, "edition-drop").contract
              , o = (0,
            r.SF)()
              , n = (0,
            m.useRouter)()
              , t = (0,
            r.YZ)(e, o)
              , d = t.data
              , l = t.isLoading
              , s = t.isError;
            return o ? l ? (0,
            _.jsx)("div", {
                children: "Loading..."
            }) : !d || s ? (0,
            _.jsx)("div", {
                children: "Error"
            }) : 0 === d.length ? (0,
            _.jsx)("div", {
                className: a().container,
                children: (0,
                _.jsx)(c, {})
            }) : (0,
            _.jsx)("div", {
                className: a().container,
                children: (0,
                _.jsx)("button", {
                    className: "".concat(a().mainButton, " ").concat(a().spacerBottom),
                    onClick: function() {
                        return n.push("/play")
                    },
                    children: "Play Game"
                })
            }) : (0,
            _.jsx)("div", {
                className: a().container,
                children: (0,
                _.jsx)(r.RZ, {
                    colorMode: "dark"
                })
            })
        }
    },
    7160: function(e) {
        e.exports = {
            connect: "Home_connect__lnU7w",
            smallMargin: "Home_smallMargin__m5aTc",
            btn: "Home_btn__UGRT9",
            address: "Home_address__UT_ly",
            container: "Home_container__bCOhY",
            page: "Home_page__0ydta",
            pageContainer: "Home_pageContainer__wDxoE",
            arrowButton: "Home_arrowButton__1aqew",
            owner: "Home_owner__58_U6",
            btnContainer: "Home_btnContainer__TOUPE",
            header: "Home_header__GCVRv",
            left: "Home_left__T7LhQ",
            right: "Home_right__TcB_0",
            secondaryButton: "Home_secondaryButton__QO332",
            mainButton: "Home_mainButton__dUc5h",
            ourCollection: "Home_ourCollection__OxOvN",
            collectionContainer: "Home_collectionContainer__pwAKU",
            h1: "Home_h1__7tdRW",
            explain: "Home_explain__KljHm",
            purple: "Home_purple__zOX0E",
            divider: "Home_divider__c4Nl_",
            smallDivider: "Home_smallDivider__wG_2a",
            textInput: "Home_textInput__cA71M",
            imageInput: "Home_imageInput__SjLEG",
            contractBoxGrid: "Home_contractBoxGrid__epSaY",
            contractBox: "Home_contractBox__bxUXm",
            nftBoxGrid: "Home_nftBoxGrid__qFzCk",
            nftBox: "Home_nftBox__woiq_",
            tokenGrid: "Home_tokenGrid__vsv91",
            tokenItem: "Home_tokenItem__HsZqC",
            tokenLabel: "Home_tokenLabel__X56dZ",
            tokenValue: "Home_tokenValue__PYZU2",
            center: "Home_center__4BFgC",
            spacerTop: "Home_spacerTop__RGZTg",
            bigSpacerTop: "Home_bigSpacerTop__YrAdY",
            spacerBottom: "Home_spacerBottom__JmsFH",
            cardName: "Home_cardName__wxcZw",
            cardDescription: "Home_cardDescription__iWMlk",
            headerLogo: "Home_headerLogo__qHj_d",
            verticalSpacer: "Home_verticalSpacer__W1YaR",
            codeSnippet: "Home_codeSnippet__gwZEn",
            noUnderline: "Home_noUnderline__SEtQc",
            detailPageContainer: "Home_detailPageContainer__7zwXF",
            detailPageHr: "Home_detailPageHr__JnD4B",
            lightPurple: "Home_lightPurple__8ghLL",
            nftMedia: "Home_nftMedia__0EkUL",
            amountToClaim: "Home_amountToClaim__p1NtW",
            noGapBottom: "Home_noGapBottom__KnGYx",
            noGapTop: "Home_noGapTop__n0WrO",
            mainSection: "Home_mainSection__QeXzC"
        }
    },
    11163: function(e, o, n) {
        e.exports = n(80880)
    }
}, function(e) {
    e.O(0, [774, 888, 179], (function() {
        return o = 48312,
        e(e.s = o);
        var o
    }
    ));
    var o = e.O();
    _N_E = o
}
]);
